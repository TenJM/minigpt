
  # Mini CookGPT - AI Cooking Assistant

  This is a code bundle for Mini CookGPT - AI Cooking Assistant. The original project is available at https://www.figma.com/design/UeZCn3wAY80HyjKrrJAXku/Mini-CookGPT---AI-Cooking-Assistant.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  