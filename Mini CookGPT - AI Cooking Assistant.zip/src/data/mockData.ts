import { Recipe } from '../types/recipe';

export const featuredRecipes: Recipe[] = [
  {
    id: '1',
    name: 'Creamy Pasta Carbonara',
    description: 'Classic Italian pasta dish with eggs, cheese, and pancetta',
    image: 'https://images.unsplash.com/photo-1711539137930-3fa2ae6cec60?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWxpY2lvdXMlMjBwYXN0YSUyMGRpc2glMjBmb29kfGVufDF8fHx8MTc1NjIwMjgwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    cookingTime: 25,
    difficulty: 'Medium',
    servings: 4,
    rating: 4.8,
    cuisine: 'Italian',
    ingredients: [
      { id: '1', name: 'Spaghetti', amount: '400', unit: 'g' },
      { id: '2', name: 'Pancetta', amount: '150', unit: 'g' },
      { id: '3', name: 'Eggs', amount: '3', unit: 'pieces' },
      { id: '4', name: 'Parmesan cheese', amount: '100', unit: 'g' },
      { id: '5', name: 'Black pepper', amount: '1', unit: 'tsp' }
    ],
    instructions: [
      'Bring a large pot of salted water to boil and cook spaghetti according to package directions.',
      'While pasta cooks, dice the pancetta and cook in a large skillet until crispy.',
      'In a bowl, whisk together eggs, grated Parmesan, and black pepper.',
      'Drain pasta, reserving 1 cup of pasta water.',
      'Add hot pasta to the pan with pancetta and remove from heat.',
      'Quickly stir in the egg mixture, adding pasta water as needed to create a creamy sauce.',
      'Serve immediately with extra Parmesan and black pepper.'
    ]
  },
  {
    id: '2',
    name: 'Fresh Garden Salad',
    description: 'Crispy mixed greens with fresh vegetables and vinaigrette',
    image: 'https://images.unsplash.com/photo-1568158958563-c13c713d69f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHNhbGFkJTIwdmVnZXRhYmxlcyUyMGhlYWx0aHl8ZW58MXx8fHwxNzU2MzE1NDUyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    cookingTime: 15,
    difficulty: 'Easy',
    servings: 2,
    rating: 4.5,
    cuisine: 'Mediterranean',
    ingredients: [
      { id: '1', name: 'Mixed greens', amount: '200', unit: 'g' },
      { id: '2', name: 'Cherry tomatoes', amount: '150', unit: 'g' },
      { id: '3', name: 'Cucumber', amount: '1', unit: 'piece' },
      { id: '4', name: 'Red onion', amount: '1/4', unit: 'piece' },
      { id: '5', name: 'Olive oil', amount: '3', unit: 'tbsp' },
      { id: '6', name: 'Balsamic vinegar', amount: '1', unit: 'tbsp' }
    ],
    instructions: [
      'Wash and dry the mixed greens thoroughly.',
      'Cut cherry tomatoes in half.',
      'Slice cucumber into rounds.',
      'Thinly slice the red onion.',
      'Combine all vegetables in a large bowl.',
      'Whisk together olive oil and balsamic vinegar.',
      'Drizzle dressing over salad and toss gently before serving.'
    ]
  },
  {
    id: '3',
    name: 'Decadent Chocolate Cake',
    description: 'Rich, moist chocolate cake with chocolate frosting',
    image: 'https://images.unsplash.com/photo-1703876086193-5d29f099205c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaG9jb2xhdGUlMjBjYWtlJTIwZGVzc2VydCUyMHN3ZWV0fGVufDF8fHx8MTc1NjMxNTQ1NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    cookingTime: 90,
    difficulty: 'Hard',
    servings: 8,
    rating: 4.9,
    cuisine: 'American',
    ingredients: [
      { id: '1', name: 'All-purpose flour', amount: '200', unit: 'g' },
      { id: '2', name: 'Cocoa powder', amount: '75', unit: 'g' },
      { id: '3', name: 'Sugar', amount: '250', unit: 'g' },
      { id: '4', name: 'Eggs', amount: '2', unit: 'pieces' },
      { id: '5', name: 'Butter', amount: '150', unit: 'g' },
      { id: '6', name: 'Dark chocolate', amount: '200', unit: 'g' }
    ],
    instructions: [
      'Preheat oven to 180°C and grease a 9-inch round cake pan.',
      'Melt butter and chocolate together in a double boiler.',
      'In a large bowl, whisk together flour, cocoa powder, and sugar.',
      'Beat eggs and add to the chocolate mixture.',
      'Combine wet and dry ingredients until just mixed.',
      'Pour batter into prepared pan and bake for 35-40 minutes.',
      'Cool completely before frosting with chocolate ganache.'
    ]
  },
  {
    id: '4',
    name: 'Grilled Chicken Breast',
    description: 'Juicy grilled chicken with herbs and spices',
    image: 'https://images.unsplash.com/photo-1577194509876-4bb24787a641?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmlsbGVkJTIwY2hpY2tlbiUyMHByb3RlaW4lMjBkaW5uZXJ8ZW58MXx8fHwxNzU2MzE1NDU4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    cookingTime: 20,
    difficulty: 'Easy',
    servings: 4,
    rating: 4.6,
    cuisine: 'American',
    ingredients: [
      { id: '1', name: 'Chicken breast', amount: '4', unit: 'pieces' },
      { id: '2', name: 'Olive oil', amount: '2', unit: 'tbsp' },
      { id: '3', name: 'Garlic powder', amount: '1', unit: 'tsp' },
      { id: '4', name: 'Dried herbs', amount: '1', unit: 'tsp' },
      { id: '5', name: 'Salt', amount: '1/2', unit: 'tsp' },
      { id: '6', name: 'Black pepper', amount: '1/4', unit: 'tsp' }
    ],
    instructions: [
      'Preheat grill to medium-high heat.',
      'Pound chicken breasts to even thickness.',
      'Mix olive oil, garlic powder, herbs, salt, and pepper.',
      'Coat chicken with the seasoning mixture.',
      'Grill chicken for 6-7 minutes per side.',
      'Check internal temperature reaches 165°F.',
      'Let rest for 5 minutes before slicing and serving.'
    ]
  },
  {
    id: '5',
    name: 'Fluffy Pancakes',
    description: 'Light and fluffy breakfast pancakes with maple syrup',
    image: 'https://images.unsplash.com/photo-1542904990-6d33b1337a21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicmVha2Zhc3QlMjBwYW5jYWtlcyUyMHN0YWNrJTIwbW9ybmluZ3xlbnwxfHx8fDE3NTYzMTU0NjF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    cookingTime: 20,
    difficulty: 'Easy',
    servings: 4,
    rating: 4.7,
    cuisine: 'American',
    ingredients: [
      { id: '1', name: 'All-purpose flour', amount: '200', unit: 'g' },
      { id: '2', name: 'Milk', amount: '250', unit: 'ml' },
      { id: '3', name: 'Eggs', amount: '2', unit: 'pieces' },
      { id: '4', name: 'Sugar', amount: '2', unit: 'tbsp' },
      { id: '5', name: 'Baking powder', amount: '2', unit: 'tsp' },
      { id: '6', name: 'Butter', amount: '50', unit: 'g' }
    ],
    instructions: [
      'Mix flour, sugar, and baking powder in a large bowl.',
      'In another bowl, whisk together milk, eggs, and melted butter.',
      'Pour wet ingredients into dry ingredients and stir until just combined.',
      'Heat a non-stick pan over medium heat.',
      'Pour 1/4 cup batter for each pancake.',
      'Cook until bubbles form on surface, then flip.',
      'Cook until golden brown and serve with maple syrup.'
    ]
  },
  {
    id: '6',
    name: 'Margherita Pizza',
    description: 'Classic Italian pizza with tomato, mozzarella, and basil',
    image: 'https://images.unsplash.com/photo-1677030002034-e1d081abfb97?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXp6YSUyMHNsaWNlJTIwaXRhbGlhbiUyMGZvb2R8ZW58MXx8fHwxNzU2MzE1NDY0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    cookingTime: 45,
    difficulty: 'Medium',
    servings: 2,
    rating: 4.8,
    cuisine: 'Italian',
    ingredients: [
      { id: '1', name: 'Pizza dough', amount: '1', unit: 'piece' },
      { id: '2', name: 'Tomato sauce', amount: '100', unit: 'ml' },
      { id: '3', name: 'Fresh mozzarella', amount: '150', unit: 'g' },
      { id: '4', name: 'Fresh basil', amount: '10', unit: 'leaves' },
      { id: '5', name: 'Olive oil', amount: '2', unit: 'tbsp' },
      { id: '6', name: 'Salt', amount: '1/2', unit: 'tsp' }
    ],
    instructions: [
      'Preheat oven to 250°C with pizza stone if available.',
      'Roll out pizza dough on floured surface.',
      'Spread tomato sauce evenly, leaving border for crust.',
      'Tear mozzarella into pieces and distribute over sauce.',
      'Drizzle with olive oil and season with salt.',
      'Bake for 10-12 minutes until crust is golden.',
      'Top with fresh basil leaves before serving.'
    ]
  }
];

export const allRecipes: Recipe[] = [...featuredRecipes];

export const cuisineTypes = [
  'All Cuisines',
  'Italian',
  'American',
  'Mediterranean',
  'Asian',
  'Mexican',
  'French',
  'Indian'
];

export const cookingTimes = [
  'Any Time',
  'Under 15 mins',
  '15-30 mins',
  '30-60 mins',
  'Over 1 hour'
];

export const difficultyLevels = [
  'All Levels',
  'Easy',
  'Medium',
  'Hard'
];