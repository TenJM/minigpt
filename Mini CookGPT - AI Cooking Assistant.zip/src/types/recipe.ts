export interface Recipe {
  id: string;
  name: string;
  description: string;
  image: string;
  cookingTime: number; // in minutes
  difficulty: 'Easy' | 'Medium' | 'Hard';
  servings: number;
  rating: number;
  cuisine: string;
  ingredients: Ingredient[];
  instructions: string[];
  isFavorite?: boolean;
}

export interface Ingredient {
  id: string;
  name: string;
  amount: string;
  unit: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  favoriteRecipes: string[];
}

export interface ChatMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  recipe?: Recipe;
}