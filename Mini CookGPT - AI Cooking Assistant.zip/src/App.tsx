import { useState } from 'react';
import { Header } from './components/Header';
import { HomePage } from './components/HomePage';
import { SearchPage } from './components/SearchPage';
import { RecipeDetailPage } from './components/RecipeDetailPage';
import { ChatPage } from './components/ChatPage';
import { ProfilePage } from './components/ProfilePage';
import { AuthPage } from './components/AuthPage';
import { Recipe } from './types/recipe';
import { featuredRecipes } from './data/mockData';

type Page = 'home' | 'recipes' | 'search' | 'recipe-detail' | 'chat' | 'favorites' | 'profile' | 'login';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [favoriteRecipes, setFavoriteRecipes] = useState<string[]>(['1', '3', '5']); // Mock favorite recipe IDs

  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
  };

  const handleRecipeClick = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setCurrentPage('recipe-detail');
  };

  const handleFavoriteToggle = (recipeId: string) => {
    setFavoriteRecipes(prev => {
      if (prev.includes(recipeId)) {
        return prev.filter(id => id !== recipeId);
      } else {
        return [...prev, recipeId];
      }
    });
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentPage('search');
  };

  const handleStartCooking = () => {
    // Could implement cooking mode functionality here
    console.log('Starting cooking mode for:', selectedRecipe?.name);
  };

  const handleBack = () => {
    setCurrentPage('home');
  };

  // Update recipes with favorite status
  const getRecipesWithFavorites = () => {
    return featuredRecipes.map(recipe => ({
      ...recipe,
      isFavorite: favoriteRecipes.includes(recipe.id)
    }));
  };

  const getFavoriteRecipes = () => {
    return getRecipesWithFavorites().filter(recipe => recipe.isFavorite);
  };

  // Render different pages based on current page
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <HomePage
            onNavigate={handleNavigate}
            onRecipeClick={handleRecipeClick}
            onFavoriteToggle={handleFavoriteToggle}
          />
        );
      
      case 'recipes':
      case 'search':
        return (
          <SearchPage
            initialQuery={searchQuery}
            onRecipeClick={handleRecipeClick}
            onFavoriteToggle={handleFavoriteToggle}
          />
        );
      
      case 'recipe-detail':
        return selectedRecipe ? (
          <RecipeDetailPage
            recipe={{
              ...selectedRecipe,
              isFavorite: favoriteRecipes.includes(selectedRecipe.id)
            }}
            onBack={handleBack}
            onFavoriteToggle={handleFavoriteToggle}
            onStartCooking={handleStartCooking}
          />
        ) : (
          <HomePage
            onNavigate={handleNavigate}
            onRecipeClick={handleRecipeClick}
            onFavoriteToggle={handleFavoriteToggle}
          />
        );
      
      case 'chat':
        return (
          <ChatPage
            onRecipeClick={handleRecipeClick}
            onFavoriteToggle={handleFavoriteToggle}
          />
        );
      
      case 'favorites':
        return (
          <div className="min-h-screen bg-gradient-to-br from-pink-50 via-red-50 to-orange-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
              <div className="text-center mb-8">
                <h1 className="text-3xl font-bold text-gray-900 mb-4">My Favorite Recipes</h1>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Your saved recipes collection. Cook them anytime!
                </p>
              </div>
              
              {getFavoriteRecipes().length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {getFavoriteRecipes().map((recipe) => (
                    <div key={recipe.id} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer" onClick={() => handleRecipeClick(recipe)}>
                      <img src={recipe.image} alt={recipe.name} className="w-full h-48 object-cover" />
                      <div className="p-4">
                        <h3 className="font-semibold text-gray-900 mb-2">{recipe.name}</h3>
                        <p className="text-sm text-gray-600 mb-3">{recipe.description}</p>
                        <div className="flex items-center justify-between text-sm text-gray-500">
                          <span>⏱️ {recipe.cookingTime}m</span>
                          <span>👥 {recipe.servings} servings</span>
                          <span>⭐ {recipe.rating}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">💔</div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">No favorites yet</h3>
                  <p className="text-gray-600 mb-6">
                    Start exploring recipes and save your favorites!
                  </p>
                  <button 
                    onClick={() => handleNavigate('recipes')}
                    className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-full transition-colors"
                  >
                    Browse Recipes
                  </button>
                </div>
              )}
            </div>
          </div>
        );
      
      case 'profile':
        return (
          <ProfilePage
            onRecipeClick={handleRecipeClick}
            onFavoriteToggle={handleFavoriteToggle}
            onNavigate={handleNavigate}
          />
        );
      
      case 'login':
        return <AuthPage onNavigate={handleNavigate} />;
      
      default:
        return (
          <HomePage
            onNavigate={handleNavigate}
            onRecipeClick={handleRecipeClick}
            onFavoriteToggle={handleFavoriteToggle}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Show header on all pages except login */}
      {currentPage !== 'login' && (
        <Header
          currentPage={currentPage}
          onNavigate={handleNavigate}
          onSearch={handleSearch}
        />
      )}
      
      {/* Main content */}
      <main className={currentPage !== 'login' ? 'pt-0' : ''}>
        {renderPage()}
      </main>

      {/* Mobile Bottom Navigation */}
      {currentPage !== 'login' && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden">
          <div className="grid grid-cols-5 gap-1">
            {[
              { id: 'home', label: 'Home', icon: '🏠' },
              { id: 'recipes', label: 'Recipes', icon: '🔍' },
              { id: 'chat', label: 'AI Chat', icon: '🤖' },
              { id: 'favorites', label: 'Favorites', icon: '❤️' },
              { id: 'profile', label: 'Profile', icon: '👤' }
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id as Page)}
                className={`py-2 px-1 text-xs flex flex-col items-center transition-colors ${
                  currentPage === item.id 
                    ? 'text-orange-600 bg-orange-50' 
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <span className="text-lg mb-1">{item.icon}</span>
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}