import { Clock, Users, Star, Heart } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Recipe } from '../types/recipe';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface RecipeCardProps {
  recipe: Recipe;
  onRecipeClick: (recipe: Recipe) => void;
  onFavoriteToggle?: (recipeId: string) => void;
  size?: 'small' | 'medium' | 'large';
}

export function RecipeCard({ recipe, onRecipeClick, onFavoriteToggle, size = 'medium' }: RecipeCardProps) {
  const sizeClasses = {
    small: 'w-full max-w-xs',
    medium: 'w-full max-w-sm',
    large: 'w-full max-w-md'
  };

  const imageClasses = {
    small: 'h-32',
    medium: 'h-40',
    large: 'h-48'
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Hard':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <Card className={`${sizeClasses[size]} cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-105 bg-white rounded-2xl overflow-hidden border-0 shadow-sm`}>
      <div className="relative">
        <ImageWithFallback
          src={recipe.image}
          alt={recipe.name}
          className={`w-full ${imageClasses[size]} object-cover`}
        />
        
        {/* Favorite Button */}
        {onFavoriteToggle && (
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/80 hover:bg-white shadow-sm"
            onClick={(e) => {
              e.stopPropagation();
              onFavoriteToggle(recipe.id);
            }}
          >
            <Heart 
              className={`w-4 h-4 ${recipe.isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} 
            />
          </Button>
        )}

        {/* Rating Badge */}
        <div className="absolute top-2 left-2">
          <Badge className="bg-black/80 text-white border-0 rounded-full px-2 py-1">
            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400 mr-1" />
            {recipe.rating}
          </Badge>
        </div>
      </div>

      <CardContent className="p-4" onClick={() => onRecipeClick(recipe)}>
        <div className="space-y-3">
          <div>
            <h3 className="font-semibold text-gray-900 line-clamp-1">{recipe.name}</h3>
            <p className="text-sm text-gray-600 line-clamp-2 mt-1">{recipe.description}</p>
          </div>

          <div className="flex items-center justify-between text-sm text-gray-500">
            <div className="flex items-center space-x-3">
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                {recipe.cookingTime}m
              </div>
              <div className="flex items-center">
                <Users className="w-4 h-4 mr-1" />
                {recipe.servings}
              </div>
            </div>
            
            <Badge 
              variant="outline" 
              className={`${getDifficultyColor(recipe.difficulty)} text-xs rounded-full px-2 py-1`}
            >
              {recipe.difficulty}
            </Badge>
          </div>

          <div className="flex items-center justify-between pt-2">
            <Badge variant="secondary" className="bg-orange-50 text-orange-700 border-orange-200 rounded-full px-3 py-1">
              {recipe.cuisine}
            </Badge>
            
            <Button
              size="sm"
              className="bg-orange-500 hover:bg-orange-600 text-white rounded-full px-4 py-2"
              onClick={(e) => {
                e.stopPropagation();
                onRecipeClick(recipe);
              }}
            >
              Cook Now
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}