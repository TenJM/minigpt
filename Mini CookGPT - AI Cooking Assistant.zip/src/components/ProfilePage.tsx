import { useState } from 'react';
import { User, Heart, Clock, ChefHat, Settings, LogOut } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { RecipeCard } from './RecipeCard';
import { Recipe } from '../types/recipe';
import { featuredRecipes } from '../data/mockData';

interface ProfilePageProps {
  onRecipeClick: (recipe: Recipe) => void;
  onFavoriteToggle: (recipeId: string) => void;
  onNavigate: (page: string) => void;
}

export function ProfilePage({ onRecipeClick, onFavoriteToggle, onNavigate }: ProfilePageProps) {
  const [activeTab, setActiveTab] = useState('favorites');

  // Mock user data
  const user = {
    name: 'Sarah Johnson',
    email: 'sarah.johnson@email.com',
    avatar: '',
    joinDate: 'January 2024',
    favoriteRecipes: ['1', '3', '5'], // IDs of favorite recipes
    recentlyCooked: ['1', '2', '4'],
    achievements: [
      { name: 'First Recipe', icon: '🍳', earned: true },
      { name: 'Pasta Master', icon: '🍝', earned: true },
      { name: 'Dessert Lover', icon: '🍰', earned: true },
      { name: 'Healthy Chef', icon: '🥗', earned: false },
      { name: 'Speed Cook', icon: '⚡', earned: false },
      { name: 'Recipe Explorer', icon: '🌟', earned: false }
    ]
  };

  const favoriteRecipes = featuredRecipes.filter(recipe => 
    user.favoriteRecipes.includes(recipe.id)
  ).map(recipe => ({ ...recipe, isFavorite: true }));

  const recentlyCooked = featuredRecipes.filter(recipe => 
    user.recentlyCooked.includes(recipe.id)
  );

  const stats = [
    { label: 'Recipes Saved', value: favoriteRecipes.length, icon: Heart, color: 'text-red-500' },
    { label: 'Recipes Cooked', value: recentlyCooked.length, icon: ChefHat, color: 'text-green-500' },
    { label: 'Total Cook Time', value: '125 min', icon: Clock, color: 'text-blue-500' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Profile Header */}
        <Card className="mb-8 border-0 rounded-2xl shadow-lg bg-white/80 backdrop-blur-sm">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
              <Avatar className="w-24 h-24">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white text-xl">
                  {user.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 text-center md:text-left">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{user.name}</h1>
                <p className="text-gray-600 mb-4">{user.email}</p>
                <div className="flex flex-wrap justify-center md:justify-start gap-2 mb-4">
                  <Badge variant="secondary" className="rounded-full">
                    Member since {user.joinDate}
                  </Badge>
                  <Badge className="bg-purple-100 text-purple-800 rounded-full">
                    Home Chef
                  </Badge>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-2">
                  <Button variant="outline" className="rounded-full">
                    <Settings className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                  <Button 
                    variant="outline" 
                    className="rounded-full text-red-600 border-red-200 hover:bg-red-50"
                    onClick={() => onNavigate('login')}
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="border-0 rounded-2xl shadow-lg bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6 text-center">
                <stat.icon className={`w-8 h-8 ${stat.color} mx-auto mb-3`} />
                <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Achievements */}
        <Card className="mb-8 border-0 rounded-2xl shadow-lg bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center">
              <span className="text-2xl mr-3">🏆</span>
              Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {user.achievements.map((achievement, index) => (
                <div 
                  key={index}
                  className={`text-center p-4 rounded-xl border-2 transition-all ${
                    achievement.earned 
                      ? 'border-yellow-300 bg-yellow-50' 
                      : 'border-gray-200 bg-gray-50 opacity-50'
                  }`}
                >
                  <div className="text-3xl mb-2">{achievement.icon}</div>
                  <div className={`text-sm font-medium ${
                    achievement.earned ? 'text-yellow-800' : 'text-gray-500'
                  }`}>
                    {achievement.name}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recipe Collections */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-2 w-full max-w-md mx-auto bg-white/80 backdrop-blur-sm rounded-full">
            <TabsTrigger value="favorites" className="rounded-full">
              <Heart className="w-4 h-4 mr-2" />
              Favorites
            </TabsTrigger>
            <TabsTrigger value="recent" className="rounded-full">
              <Clock className="w-4 h-4 mr-2" />
              Recently Cooked
            </TabsTrigger>
          </TabsList>

          <TabsContent value="favorites">
            <Card className="border-0 rounded-2xl shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>My Favorite Recipes</CardTitle>
                <p className="text-gray-600">Recipes you've saved for later</p>
              </CardHeader>
              <CardContent>
                {favoriteRecipes.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {favoriteRecipes.map((recipe) => (
                      <RecipeCard
                        key={recipe.id}
                        recipe={recipe}
                        onRecipeClick={onRecipeClick}
                        onFavoriteToggle={onFavoriteToggle}
                        size="medium"
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="text-6xl mb-4">💔</div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No favorites yet</h3>
                    <p className="text-gray-600 mb-6">
                      Start exploring recipes and save your favorites!
                    </p>
                    <Button 
                      onClick={() => onNavigate('recipes')}
                      className="bg-purple-500 hover:bg-purple-600 text-white rounded-full"
                    >
                      Browse Recipes
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recent">
            <Card className="border-0 rounded-2xl shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Recently Cooked</CardTitle>
                <p className="text-gray-600">Recipes you've made recently</p>
              </CardHeader>
              <CardContent>
                {recentlyCooked.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {recentlyCooked.map((recipe) => (
                      <RecipeCard
                        key={recipe.id}
                        recipe={recipe}
                        onRecipeClick={onRecipeClick}
                        onFavoriteToggle={onFavoriteToggle}
                        size="medium"
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="text-6xl mb-4">👨‍🍳</div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No recipes cooked yet</h3>
                    <p className="text-gray-600 mb-6">
                      Start cooking and track your culinary journey!
                    </p>
                    <Button 
                      onClick={() => onNavigate('chat')}
                      className="bg-purple-500 hover:bg-purple-600 text-white rounded-full"
                    >
                      Get Recipe Suggestions
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

      </div>
    </div>
  );
}