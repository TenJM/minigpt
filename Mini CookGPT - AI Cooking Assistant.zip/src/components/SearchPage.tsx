import { useState, useMemo } from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { RecipeCard } from './RecipeCard';
import { Recipe } from '../types/recipe';
import { allRecipes, cuisineTypes, cookingTimes, difficultyLevels } from '../data/mockData';

interface SearchPageProps {
  initialQuery?: string;
  onRecipeClick: (recipe: Recipe) => void;
  onFavoriteToggle: (recipeId: string) => void;
}

export function SearchPage({ initialQuery = '', onRecipeClick, onFavoriteToggle }: SearchPageProps) {
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [selectedCuisine, setSelectedCuisine] = useState('All Cuisines');
  const [selectedTime, setSelectedTime] = useState('Any Time');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All Levels');
  const [showFilters, setShowFilters] = useState(false);

  const filteredRecipes = useMemo(() => {
    return allRecipes.filter(recipe => {
      // Search query filter
      const matchesSearch = searchQuery === '' || 
        recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        recipe.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        recipe.ingredients.some(ingredient => 
          ingredient.name.toLowerCase().includes(searchQuery.toLowerCase())
        );

      // Cuisine filter
      const matchesCuisine = selectedCuisine === 'All Cuisines' || recipe.cuisine === selectedCuisine;

      // Difficulty filter
      const matchesDifficulty = selectedDifficulty === 'All Levels' || recipe.difficulty === selectedDifficulty;

      // Time filter
      let matchesTime = true;
      if (selectedTime !== 'Any Time') {
        switch (selectedTime) {
          case 'Under 15 mins':
            matchesTime = recipe.cookingTime < 15;
            break;
          case '15-30 mins':
            matchesTime = recipe.cookingTime >= 15 && recipe.cookingTime <= 30;
            break;
          case '30-60 mins':
            matchesTime = recipe.cookingTime > 30 && recipe.cookingTime <= 60;
            break;
          case 'Over 1 hour':
            matchesTime = recipe.cookingTime > 60;
            break;
        }
      }

      return matchesSearch && matchesCuisine && matchesDifficulty && matchesTime;
    });
  }, [searchQuery, selectedCuisine, selectedTime, selectedDifficulty]);

  const clearFilters = () => {
    setSelectedCuisine('All Cuisines');
    setSelectedTime('Any Time');
    setSelectedDifficulty('All Levels');
  };

  const hasActiveFilters = selectedCuisine !== 'All Cuisines' || selectedTime !== 'Any Time' || selectedDifficulty !== 'All Levels';

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Discover Recipes</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Find the perfect recipe for any occasion. Search by ingredients, cuisine, or cooking time.
          </p>
        </div>

        {/* Search Bar */}
        <Card className="mb-6 border-0 rounded-2xl shadow-lg bg-white/80 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder="Search recipes, ingredients, or cuisines..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 pr-4 py-3 rounded-full border-gray-200 focus:border-green-300 focus:ring-green-200"
                />
              </div>
              
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="rounded-full px-6 py-3 border-gray-200 hover:bg-gray-50"
              >
                <Filter className="w-4 h-4 mr-2" />
                Filters
                {hasActiveFilters && (
                  <Badge className="ml-2 bg-green-500 text-white rounded-full w-5 h-5 p-0 flex items-center justify-center">
                    !
                  </Badge>
                )}
              </Button>
            </div>

            {/* Filters */}
            {showFilters && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Cuisine</label>
                    <Select value={selectedCuisine} onValueChange={setSelectedCuisine}>
                      <SelectTrigger className="w-full rounded-xl">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {cuisineTypes.map((cuisine) => (
                          <SelectItem key={cuisine} value={cuisine}>
                            {cuisine}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Cooking Time</label>
                    <Select value={selectedTime} onValueChange={setSelectedTime}>
                      <SelectTrigger className="w-full rounded-xl">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {cookingTimes.map((time) => (
                          <SelectItem key={time} value={time}>
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Difficulty</label>
                    <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                      <SelectTrigger className="w-full rounded-xl">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {difficultyLevels.map((difficulty) => (
                          <SelectItem key={difficulty} value={difficulty}>
                            {difficulty}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {hasActiveFilters && (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-gray-600">Active filters:</span>
                      {selectedCuisine !== 'All Cuisines' && (
                        <Badge variant="secondary" className="rounded-full">
                          {selectedCuisine}
                          <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => setSelectedCuisine('All Cuisines')} />
                        </Badge>
                      )}
                      {selectedTime !== 'Any Time' && (
                        <Badge variant="secondary" className="rounded-full">
                          {selectedTime}
                          <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => setSelectedTime('Any Time')} />
                        </Badge>
                      )}
                      {selectedDifficulty !== 'All Levels' && (
                        <Badge variant="secondary" className="rounded-full">
                          {selectedDifficulty}
                          <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => setSelectedDifficulty('All Levels')} />
                        </Badge>
                      )}
                    </div>
                    <Button variant="ghost" onClick={clearFilters} className="text-sm">
                      Clear all
                    </Button>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">
              {searchQuery ? `Search results for "${searchQuery}"` : 'All Recipes'}
            </h2>
            <span className="text-sm text-gray-600">
              {filteredRecipes.length} recipe{filteredRecipes.length !== 1 ? 's' : ''} found
            </span>
          </div>

          {filteredRecipes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredRecipes.map((recipe) => (
                <RecipeCard
                  key={recipe.id}
                  recipe={recipe}
                  onRecipeClick={onRecipeClick}
                  onFavoriteToggle={onFavoriteToggle}
                  size="medium"
                />
              ))}
            </div>
          ) : (
            <Card className="border-0 rounded-2xl shadow-lg bg-white/80 backdrop-blur-sm">
              <CardContent className="p-12 text-center">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No recipes found</h3>
                <p className="text-gray-600 mb-6">
                  Try adjusting your search terms or filters to find more recipes.
                </p>
                <Button onClick={clearFilters} className="bg-green-500 hover:bg-green-600 text-white rounded-full">
                  Clear Filters
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Popular Searches */}
        <Card className="border-0 rounded-2xl shadow-lg bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>Popular Searches</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {['Pasta', 'Chicken', 'Vegetarian', 'Dessert', 'Quick meals', 'Healthy', 'Italian', 'Breakfast'].map((term) => (
                <Button
                  key={term}
                  variant="outline"
                  size="sm"
                  onClick={() => setSearchQuery(term)}
                  className="rounded-full border-gray-200 hover:border-green-300 hover:bg-green-50"
                >
                  {term}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}