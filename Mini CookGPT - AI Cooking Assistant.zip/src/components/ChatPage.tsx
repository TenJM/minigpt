import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { RecipeCard } from './RecipeCard';
import { ChatMessage, Recipe } from '../types/recipe';
import { featuredRecipes } from '../data/mockData';

interface ChatPageProps {
  onRecipeClick: (recipe: Recipe) => void;
  onFavoriteToggle: (recipeId: string) => void;
}

export function ChatPage({ onRecipeClick, onFavoriteToggle }: ChatPageProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'assistant',
      content: "Hi there! I'm your AI cooking assistant. I can help you with recipe suggestions, cooking tips, ingredient substitutions, and much more. What would you like to cook today?",
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const suggestedPrompts = [
    "What can I make with chicken and rice?",
    "Quick 15-minute dinner ideas",
    "Healthy breakfast recipes",
    "How to make pasta carbonara?",
    "Vegetarian meal prep ideas",
    "Desserts without eggs"
  ];

  const generateAIResponse = (userMessage: string): { content: string; recipe?: Recipe } => {
    const lowerMessage = userMessage.toLowerCase();
    
    // Simple pattern matching for demo purposes
    if (lowerMessage.includes('chicken') || lowerMessage.includes('protein')) {
      const chickenRecipe = featuredRecipes.find(r => r.name.toLowerCase().includes('chicken'));
      return {
        content: "I found a great chicken recipe for you! Grilled chicken breast is a healthy and versatile option. You can season it with herbs and spices, and it pairs well with vegetables or rice. Here's one of my favorite recipes:",
        recipe: chickenRecipe
      };
    }
    
    if (lowerMessage.includes('pasta') || lowerMessage.includes('carbonara')) {
      const pastaRecipe = featuredRecipes.find(r => r.name.toLowerCase().includes('pasta'));
      return {
        content: "Pasta is always a great choice! For a classic carbonara, you'll want to use eggs, cheese, and pancetta to create that creamy sauce. Here's an authentic recipe:",
        recipe: pastaRecipe
      };
    }
    
    if (lowerMessage.includes('quick') || lowerMessage.includes('15 minute') || lowerMessage.includes('fast')) {
      return {
        content: "For quick meals, I recommend dishes that take 20 minutes or less. Here are some ideas: stir-fries, pasta dishes, salads, sandwiches, or simple grilled proteins. Would you like specific recipes for any of these?"
      };
    }
    
    if (lowerMessage.includes('breakfast') || lowerMessage.includes('morning')) {
      const breakfastRecipe = featuredRecipes.find(r => r.name.toLowerCase().includes('pancake'));
      return {
        content: "Breakfast is the most important meal of the day! You could try pancakes, eggs, oatmeal, or smoothies. Here's a fluffy pancake recipe that's always a hit:",
        recipe: breakfastRecipe
      };
    }
    
    if (lowerMessage.includes('healthy') || lowerMessage.includes('vegetables')) {
      const saladRecipe = featuredRecipes.find(r => r.name.toLowerCase().includes('salad'));
      return {
        content: "Eating healthy is a great choice! Focus on fresh vegetables, lean proteins, and whole grains. Salads are an excellent way to get lots of nutrients. Here's a fresh garden salad recipe:",
        recipe: saladRecipe
      };
    }
    
    if (lowerMessage.includes('dessert') || lowerMessage.includes('sweet') || lowerMessage.includes('cake')) {
      const dessertRecipe = featuredRecipes.find(r => r.name.toLowerCase().includes('chocolate'));
      return {
        content: "Who doesn't love a good dessert? Chocolate cake is always a crowd-pleaser. It requires some baking skills, but the result is worth it! Here's a decadent recipe:",
        recipe: dessertRecipe
      };
    }
    
    // Default responses
    const defaultResponses = [
      "That's an interesting question! Could you tell me more about what type of cuisine you're in the mood for?",
      "I'd love to help you with that! Do you have any dietary restrictions or preferences I should know about?",
      "Great question! Are you looking for something quick and easy, or do you have time for a more elaborate recipe?",
      "I can definitely help with that! What ingredients do you currently have available?",
      "That sounds delicious! Would you like me to suggest some recipes based on your preferences?"
    ];
    
    return {
      content: defaultResponses[Math.floor(Math.random() * defaultResponses.length)]
    };
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI response delay
    setTimeout(() => {
      const response = generateAIResponse(inputMessage);
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: response.content,
        timestamp: new Date(),
        recipe: response.recipe
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handlePromptClick = (prompt: string) => {
    setInputMessage(prompt);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mr-4">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">AI Cooking Assistant</h1>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Ask me anything about cooking! I can suggest recipes, provide cooking tips, 
            help with ingredient substitutions, and guide you through any culinary challenge.
          </p>
        </div>

        {/* Chat Container */}
        <Card className="mb-6 border-0 rounded-2xl shadow-lg bg-white/80 backdrop-blur-sm">
          <CardContent className="p-0">
            
            {/* Messages */}
            <div className="h-96 overflow-y-auto p-6 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <Avatar className="w-8 h-8 mx-2 flex-shrink-0">
                      <AvatarFallback className={message.type === 'user' ? 'bg-orange-500' : 'bg-blue-500'}>
                        {message.type === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="space-y-3">
                      <div
                        className={`rounded-2xl px-4 py-3 ${
                          message.type === 'user'
                            ? 'bg-orange-500 text-white'
                            : 'bg-gray-100 text-gray-900'
                        }`}
                      >
                        <p className="whitespace-pre-wrap">{message.content}</p>
                      </div>
                      
                      {/* Recipe Card in Chat */}
                      {message.recipe && (
                        <div className="max-w-xs">
                          <RecipeCard
                            recipe={message.recipe}
                            onRecipeClick={onRecipeClick}
                            onFavoriteToggle={onFavoriteToggle}
                            size="small"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Typing Indicator */}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex">
                    <Avatar className="w-8 h-8 mr-2">
                      <AvatarFallback className="bg-blue-500">
                        <Bot className="w-4 h-4 text-white" />
                      </AvatarFallback>
                    </Avatar>
                    <div className="bg-gray-100 rounded-2xl px-4 py-3">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
            
            {/* Input Area */}
            <div className="border-t p-4">
              <div className="flex items-center space-x-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me anything about cooking..."
                  className="flex-1 rounded-full border-gray-200 focus:border-blue-300 focus:ring-blue-200"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || isTyping}
                  className="rounded-full bg-blue-500 hover:bg-blue-600 text-white w-10 h-10 p-0"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
          </CardContent>
        </Card>

        {/* Suggested Prompts */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Sparkles className="w-5 h-5 mr-2 text-yellow-500" />
            Try asking me:
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {suggestedPrompts.map((prompt, index) => (
              <Button
                key={index}
                variant="outline"
                onClick={() => handlePromptClick(prompt)}
                className="text-left justify-start rounded-xl border-gray-200 hover:border-blue-300 hover:bg-blue-50 p-4 h-auto whitespace-normal"
              >
                <span className="text-sm">{prompt}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: '🍳',
              title: 'Recipe Suggestions',
              description: 'Get personalized recipe recommendations based on your preferences and available ingredients.'
            },
            {
              icon: '💡',
              title: 'Cooking Tips',
              description: 'Learn professional cooking techniques and tips to improve your culinary skills.'
            },
            {
              icon: '🔄',
              title: 'Substitutions',
              description: 'Find ingredient substitutions when you\'re missing something for your recipe.'
            }
          ].map((feature, index) => (
            <Card key={index} className="border-0 rounded-2xl shadow-lg bg-white/70 backdrop-blur-sm">
              <CardContent className="p-6 text-center">
                <div className="text-3xl mb-3">{feature.icon}</div>
                <h4 className="font-semibold text-gray-900 mb-2">{feature.title}</h4>
                <p className="text-sm text-gray-600">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

      </div>
    </div>
  );
}