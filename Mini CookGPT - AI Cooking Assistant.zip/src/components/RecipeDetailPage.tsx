import { useState } from 'react';
import { ArrowLeft, Clock, Users, ChefHat, Heart, Share2, Printer } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Progress } from './ui/progress';
import { Recipe } from '../types/recipe';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface RecipeDetailPageProps {
  recipe: Recipe;
  onBack: () => void;
  onFavoriteToggle: (recipeId: string) => void;
  onStartCooking: () => void;
}

export function RecipeDetailPage({ recipe, onBack, onFavoriteToggle, onStartCooking }: RecipeDetailPageProps) {
  const [checkedIngredients, setCheckedIngredients] = useState<{ [key: string]: boolean }>({});
  const [currentStep, setCurrentStep] = useState(0);
  const [isCookingMode, setIsCookingMode] = useState(false);

  const handleIngredientCheck = (ingredientId: string) => {
    setCheckedIngredients(prev => ({
      ...prev,
      [ingredientId]: !prev[ingredientId]
    }));
  };

  const checkedCount = Object.values(checkedIngredients).filter(Boolean).length;
  const progressPercentage = (checkedCount / recipe.ingredients.length) * 100;

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Hard':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleStartCooking = () => {
    setIsCookingMode(true);
    setCurrentStep(0);
    onStartCooking();
  };

  const nextStep = () => {
    if (currentStep < recipe.instructions.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-yellow-50 to-green-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            onClick={onBack}
            className="rounded-full hover:bg-white/50"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              className="rounded-full"
              onClick={() => onFavoriteToggle(recipe.id)}
            >
              <Heart className={`w-4 h-4 mr-1 ${recipe.isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
              {recipe.isFavorite ? 'Saved' : 'Save'}
            </Button>
            <Button variant="outline" size="sm" className="rounded-full">
              <Share2 className="w-4 h-4 mr-1" />
              Share
            </Button>
            <Button variant="outline" size="sm" className="rounded-full">
              <Printer className="w-4 h-4 mr-1" />
              Print
            </Button>
          </div>
        </div>

        {/* Recipe Hero */}
        <Card className="mb-8 border-0 rounded-2xl overflow-hidden shadow-lg bg-white">
          <div className="relative">
            <ImageWithFallback
              src={recipe.image}
              alt={recipe.name}
              className="w-full h-64 md:h-80 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 text-white">
              <h1 className="text-3xl md:text-4xl font-bold mb-2">{recipe.name}</h1>
              <p className="text-lg opacity-90">{recipe.description}</p>
            </div>
          </div>

          <CardContent className="p-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center">
                <Clock className="w-6 h-6 text-orange-500 mx-auto mb-1" />
                <div className="font-semibold">{recipe.cookingTime} min</div>
                <div className="text-sm text-gray-500">Cook Time</div>
              </div>
              <div className="text-center">
                <Users className="w-6 h-6 text-green-500 mx-auto mb-1" />
                <div className="font-semibold">{recipe.servings}</div>
                <div className="text-sm text-gray-500">Servings</div>
              </div>
              <div className="text-center">
                <ChefHat className="w-6 h-6 text-blue-500 mx-auto mb-1" />
                <div className="font-semibold">{recipe.difficulty}</div>
                <div className="text-sm text-gray-500">Difficulty</div>
              </div>
              <div className="text-center">
                <div className="text-yellow-500 text-xl mb-1">★</div>
                <div className="font-semibold">{recipe.rating}</div>
                <div className="text-sm text-gray-500">Rating</div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <Badge 
                variant="outline" 
                className="bg-orange-50 text-orange-700 border-orange-200 rounded-full px-4 py-2"
              >
                {recipe.cuisine} Cuisine
              </Badge>
              
              <Button
                onClick={handleStartCooking}
                className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white rounded-full px-6 py-2"
              >
                <ChefHat className="w-4 h-4 mr-2" />
                Start Cooking
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Ingredients */}
          <Card className="border-0 rounded-2xl shadow-lg bg-white">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Ingredients</span>
                <div className="text-sm text-gray-500">
                  {checkedCount}/{recipe.ingredients.length} checked
                </div>
              </CardTitle>
              <Progress value={progressPercentage} className="w-full" />
            </CardHeader>
            <CardContent className="space-y-3">
              {recipe.ingredients.map((ingredient) => (
                <div 
                  key={ingredient.id} 
                  className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <Checkbox
                    id={ingredient.id}
                    checked={checkedIngredients[ingredient.id] || false}
                    onCheckedChange={() => handleIngredientCheck(ingredient.id)}
                  />
                  <label 
                    htmlFor={ingredient.id}
                    className={`flex-1 cursor-pointer ${
                      checkedIngredients[ingredient.id] ? 'line-through text-gray-500' : ''
                    }`}
                  >
                    <span className="font-medium">{ingredient.amount} {ingredient.unit}</span>
                    <span className="ml-2">{ingredient.name}</span>
                  </label>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Instructions */}
          <Card className="border-0 rounded-2xl shadow-lg bg-white">
            <CardHeader>
              <CardTitle>Instructions</CardTitle>
              {isCookingMode && (
                <div className="text-sm text-gray-500">
                  Step {currentStep + 1} of {recipe.instructions.length}
                </div>
              )}
            </CardHeader>
            <CardContent>
              {isCookingMode ? (
                // Cooking Mode
                <div className="space-y-6">
                  <div className="bg-orange-50 border border-orange-200 rounded-xl p-4">
                    <div className="text-sm text-orange-600 font-medium mb-2">
                      Step {currentStep + 1}
                    </div>
                    <p className="text-gray-900 leading-relaxed">
                      {recipe.instructions[currentStep]}
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Button
                      variant="outline"
                      onClick={prevStep}
                      disabled={currentStep === 0}
                      className="rounded-full"
                    >
                      Previous
                    </Button>
                    
                    <Progress 
                      value={((currentStep + 1) / recipe.instructions.length) * 100} 
                      className="w-32 mx-4" 
                    />
                    
                    <Button
                      onClick={nextStep}
                      disabled={currentStep === recipe.instructions.length - 1}
                      className="bg-orange-500 hover:bg-orange-600 text-white rounded-full"
                    >
                      {currentStep === recipe.instructions.length - 1 ? 'Finish' : 'Next'}
                    </Button>
                  </div>
                  
                  {currentStep === recipe.instructions.length - 1 && (
                    <div className="text-center p-4 bg-green-50 border border-green-200 rounded-xl">
                      <div className="text-2xl mb-2">🎉</div>
                      <p className="text-green-800 font-medium">
                        Congratulations! You've completed the recipe!
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                // Regular Mode
                <div className="space-y-4">
                  {recipe.instructions.map((instruction, index) => (
                    <div key={index} className="flex space-x-4">
                      <div className="flex-shrink-0 w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center font-medium">
                        {index + 1}
                      </div>
                      <p className="text-gray-700 leading-relaxed pt-1">{instruction}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* AI Assistant Suggestion */}
        <Card className="mt-8 border-0 rounded-2xl shadow-lg bg-gradient-to-r from-green-100 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="text-3xl">🤖</div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 mb-1">Need cooking help?</h3>
                <p className="text-gray-700">Ask our AI assistant for tips, substitutions, or cooking techniques for this recipe.</p>
              </div>
              <Button 
                className="bg-green-500 hover:bg-green-600 text-white rounded-full"
                onClick={() => {/* Navigate to chat with recipe context */}}
              >
                Ask AI
              </Button>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}