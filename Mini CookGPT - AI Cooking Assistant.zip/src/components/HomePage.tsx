import { useState } from 'react';
import { Shuffle, TrendingUp, Clock, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { RecipeCard } from './RecipeCard';
import { Recipe } from '../types/recipe';
import { featuredRecipes } from '../data/mockData';

interface HomePageProps {
  onNavigate: (page: string) => void;
  onRecipeClick: (recipe: Recipe) => void;
  onFavoriteToggle: (recipeId: string) => void;
}

export function HomePage({ onNavigate, onRecipeClick, onFavoriteToggle }: HomePageProps) {
  const [surpriseRecipe, setSurpriseRecipe] = useState<Recipe | null>(null);

  const handleSurpriseMe = () => {
    const randomRecipe = featuredRecipes[Math.floor(Math.random() * featuredRecipes.length)];
    setSurpriseRecipe(randomRecipe);
  };

  const quickStats = [
    { label: 'Total Recipes', value: '1000+', icon: TrendingUp, color: 'text-green-600' },
    { label: 'Avg Cook Time', value: '25 min', icon: Clock, color: 'text-blue-600' },
    { label: 'User Rating', value: '4.8★', icon: Star, color: 'text-yellow-600' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-yellow-50 to-green-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="mb-6">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4">
              Welcome to{' '}
              <span className="bg-gradient-to-r from-orange-500 to-yellow-500 bg-clip-text text-transparent">
                Mini CookGPT
              </span>
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Your AI-powered cooking companion. Discover delicious recipes, get personalized meal ideas, 
              and cook with confidence!
            </p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto mb-8">
            {quickStats.map((stat, index) => (
              <Card key={index} className="bg-white/70 backdrop-blur-sm border-0 rounded-2xl">
                <CardContent className="p-4 text-center">
                  <stat.icon className={`w-8 h-8 ${stat.color} mx-auto mb-2`} />
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Surprise Me Button */}
          <div className="mb-8">
            <Button
              onClick={handleSurpriseMe}
              size="lg"
              className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white rounded-full px-8 py-3 shadow-lg hover:shadow-xl transition-all duration-200"
            >
              <Shuffle className="w-5 h-5 mr-2" />
              Surprise Me!
            </Button>
          </div>

          {/* Surprise Recipe Result */}
          {surpriseRecipe && (
            <div className="mb-8">
              <div className="bg-white rounded-2xl p-6 shadow-lg max-w-md mx-auto">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">🎲 Your Surprise Recipe:</h3>
                <RecipeCard 
                  recipe={surpriseRecipe} 
                  onRecipeClick={onRecipeClick}
                  onFavoriteToggle={onFavoriteToggle}
                  size="small"
                />
              </div>
            </div>
          )}
        </div>

        {/* Featured Recipes Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Featured Recipes</h2>
              <p className="text-gray-600">Handpicked delicious recipes just for you</p>
            </div>
            <Button
              variant="outline"
              onClick={() => onNavigate('recipes')}
              className="rounded-full border-orange-200 text-orange-600 hover:bg-orange-50"
            >
              View All Recipes
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredRecipes.slice(0, 6).map((recipe) => (
              <RecipeCard
                key={recipe.id}
                recipe={recipe}
                onRecipeClick={onRecipeClick}
                onFavoriteToggle={onFavoriteToggle}
                size="medium"
              />
            ))}
          </div>
        </section>

        {/* Quick Actions */}
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <Card 
            className="bg-gradient-to-br from-green-100 to-green-200 border-0 rounded-2xl cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105"
            onClick={() => onNavigate('chat')}
          >
            <CardHeader>
              <CardTitle className="flex items-center text-green-800">
                <span className="text-2xl mr-3">🤖</span>
                Ask AI Assistant
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-green-700">
                Get instant cooking advice, recipe suggestions, and culinary tips from our AI chef.
              </p>
            </CardContent>
          </Card>

          <Card 
            className="bg-gradient-to-br from-yellow-100 to-yellow-200 border-0 rounded-2xl cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105"
            onClick={() => onNavigate('favorites')}
          >
            <CardHeader>
              <CardTitle className="flex items-center text-yellow-800">
                <span className="text-2xl mr-3">❤️</span>
                My Favorites
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-yellow-700">
                Access your saved recipes and build your personal cookbook collection.
              </p>
            </CardContent>
          </Card>

          <Card 
            className="bg-gradient-to-br from-orange-100 to-orange-200 border-0 rounded-2xl cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105"
            onClick={() => onNavigate('recipes')}
          >
            <CardHeader>
              <CardTitle className="flex items-center text-orange-800">
                <span className="text-2xl mr-3">🔍</span>
                Browse Recipes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-orange-700">
                Explore our extensive collection of recipes with advanced filtering options.
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Categories Preview */}
        <section>
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Popular Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[
              { name: 'Breakfast', emoji: '🥞', count: '120+' },
              { name: 'Lunch', emoji: '🥗', count: '200+' },
              { name: 'Dinner', emoji: '🍝', count: '300+' },
              { name: 'Desserts', emoji: '🍰', count: '150+' },
              { name: 'Vegetarian', emoji: '🥬', count: '180+' },
              { name: 'Quick Meals', emoji: '⚡', count: '90+' }
            ].map((category, index) => (
              <Card 
                key={index}
                className="bg-white border-0 rounded-2xl cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105"
                onClick={() => onNavigate('recipes')}
              >
                <CardContent className="p-4 text-center">
                  <div className="text-3xl mb-2">{category.emoji}</div>
                  <div className="font-semibold text-gray-900">{category.name}</div>
                  <div className="text-sm text-gray-500">{category.count}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

      </div>
    </div>
  );
}